//
//  ViewController.swift
//  example
//
//  Created by Bolat Abdii on 30.12.2021.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

