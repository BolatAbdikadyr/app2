//
//  ViewController.swift
//  1assi
//
//  Created by Bolat Abdii on 03.01.2022.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

